

import { Button, Card, Typography } from "@mui/material";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
//file import starts here
import { Navbar } from "../Navbar";
import './Postdeatils.css';
//file import ends here

export function Postdeatils(){

    return(
        <>
            <Navbar/>
            <Card className="main-body-posts-profile-deatils">
            <Button className='back-btn' sx={{color:'black',textTransform:'none'}} > <ArrowBackIcon/><Typography >Back</Typography></Button>

            </Card>

        </>
    )
}