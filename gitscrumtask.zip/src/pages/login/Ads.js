import { Box } from "@mui/material";
import { Navbar } from "./Navbar";


export function Ads(){

    return(
        <>
        <Navbar/>
          
<Box sx={{marginLeft:'250px'}}>
Orders
 

</Box>
        </>
    )
}