
import { BrowserRouter, Link, Route, Routes, useLocation } from 'react-router-dom';
import './App.css';
import { AddOrderslanding } from './pages/login/AddOrderslanding';
import { Ads } from './pages/login/Ads';
import { Dashboard } from './pages/login/Dashboard/Dashboard';
import { Home } from './pages/login/Home';

import { Login } from './pages/login/Login';
import { Orders } from './pages/login/Orders';
import { OrdersFoodandAccessories } from './pages/login/OrdersFoodandAccessories';
import { Orderslanding } from './pages/login/Orderslanding';
import { Posts } from './pages/login/Posts';
import { Postdeatils } from './pages/login/Posts/Postdeatils';
function App() {

  return (
    
    <div>
   <BrowserRouter>
      <Link to={'/'}/>
      <Routes>
        
        <Route path='/'element={<Login/>}></Route>
        <Route path='/home' element={<Home/>}></Route>
        <Route path='/orders-home' element={<Orderslanding/>}></Route>
    <Route path='/orders' element={<Orders/>}></Route>
    <Route path='/posts' element={<Posts/>}></Route>
    <Route path='/ads' element={<Ads/>}></Route>

    <Route path='/orders-food&Accessories' element={<OrdersFoodandAccessories/>}></Route>
    <Route path='/post-deatils' element={<Postdeatils/>}></Route>

    <Route path='/pet-place-order' element={<AddOrderslanding/>}></Route>

      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
